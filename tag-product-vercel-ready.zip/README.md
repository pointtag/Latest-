# Tag Product App
A simple React app for LED TV product ordering.