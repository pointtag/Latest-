import React from 'react';

function App() {
  return (
    <div style={{ padding: 20, fontFamily: 'Arial' }}>
      <h1>Tag LED TV</h1>
      <p>Welcome! Choose your LED TV and place an order.</p>
    </div>
  );
}

export default App;
